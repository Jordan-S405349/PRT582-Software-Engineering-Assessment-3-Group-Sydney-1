# online-movie-ticket-booking-system
This is an online movie ticket booking website  made using following technologies:-
  1. Python-3.6
  2. Django-2.0.3
  3. JavaScript
  4. JQuery-3.3.1
  5. Bootstrap3

This project contains following apps:-
  1. theatre app
  2. movie app
  3. booking app
  4. home app
 
 In this project custom user model has been used rather than default user model.

 There are list and detail views of theatre, movie etc. 
 Movie list view displays the movie.
 Theatre list view displays all the theatres in a city.
 Booking list view displays our booking.


---

### Steps to run the application using Docker and Docker Compose:

1. First, clone the repository to your local machine.
2. Install Docker.
3. Switch to the project directory.
4. Run the following command in the terminal:
   `docker compose up --build`
5. Open your browser and go to:

   * Application: [http://localhost:8000/](http://localhost:8000/)
   * Admin panel: [http://localhost:8000/admin/](http://localhost:8000/admin/)
6. Update the date and time fields of Show Model from Admin Panel to make shows available for booking in the EndUser Application [http://localhost:8000/](http://localhost:8000/).   
7. Check the `docker-compose.yml` file for admin credentials.
8. Enjoy!

---


 
